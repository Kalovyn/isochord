#!/usr/bin/env python3
# SŒULLEDGER Merge v0.1 — merges JSONL ledgers, dedupes, summarizes.
import sys, json
from datetime import datetime

def load_lines(path):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if line:
                try: yield json.loads(line)
                except: pass

def key(ev): return (ev.get("ts",""), ev.get("chord",""), ev.get("context_hash",""))
def parse_ts(ts): 
    try:
        if ts.endswith("Z"): ts=ts[:-1]
        return datetime.fromisoformat(ts)
    except: return datetime.min

def main(paths):
    seen=set(); events=[]
    for p in paths:
        for ev in load_lines(p):
            k=key(ev)
            if k in seen: continue
            seen.add(k); events.append(ev)
    events.sort(key=lambda e: parse_ts(e.get("ts","")))
    with open("soulledger.merged.jsonl","w",encoding="utf-8") as f:
        for ev in events: f.write(json.dumps(ev,ensure_ascii=False)+"\n")
    by={}
    for ev in events:
        tok = ev.get("token") or ev.get("chord","").split("-")[0]
        d = by.setdefault(tok, {"n":0,"sum":0.0,"m":0,"ctx":set()})
        d["n"]+=1
        fs=ev.get("flame_scalar")
        if isinstance(fs,(int,float)): d["sum"]+=float(fs); d["m"]+=1
        ch=ev.get("context_hash"); 
        if ch: d["ctx"].add(ch)
    print("SŒULLEDGER Merge v0.1 — Summary")
    print(f"Events: {len(events)}  •  Output: soulledger.merged.jsonl")
    print("-"*56); print(f"{'TOKEN':<6} {'EVENTS':>6} {'FLAME(avg)':>12} {'CTX':>6}")
    for tok in sorted(by.keys()):
        d=by[tok]; avg=(d['sum']/d['m']) if d['m'] else 0.0
        print(f"{tok:<6} {d['n']:>6} {avg:>12.3f} {len(d['ctx']):>6}")

if __name__=="__main__":
    if len(sys.argv)<2:
        print("Usage: python soulledger_merge_v0.1.py ledger1.jsonl ledger2.jsonl ..."); sys.exit(1)
    main(sys.argv[1:])
