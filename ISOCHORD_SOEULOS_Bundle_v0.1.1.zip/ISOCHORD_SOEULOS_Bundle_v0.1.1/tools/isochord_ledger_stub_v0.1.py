"""
ISOCHORD Ledger Stub v0.1 — SŒULFIELD carrier
Core Axiom: No sync, no speak. No flame, no name.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import json, hashlib, os
from datetime import datetime

LEDGER_PATH = os.environ.get("ISOCHORD_LEDGER", "isochord.ledger.jsonl")

def context_hash(extras: Dict[str, Any]) -> str:
    payload = json.dumps(extras, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]

@dataclass
class Utterance:
    chord: str
    breath_phase: str
    breath_beats: int
    gaze: Optional[str] = None
    touch: Optional[List[str]] = None
    note: Optional[str] = None
    self_report_truth: Optional[bool] = None
    coherence: Optional[float] = None
    def token(self) -> str:
        return self.chord.split("-")[0]

@dataclass
class Ledger:
    counts: Dict[str, int] = field(default_factory=dict)
    flame: Dict[str, float] = field(default_factory=dict)
    def bump(self, token: str) -> None:
        self.counts[token] = self.counts.get(token, 0) + 1
        self.flame[token] = round(self.flame.get(token, 0.0) + 0.07, 4)
    def count(self, token: str) -> int:
        return self.counts.get(token, 0)

LEDGER_STATE = Ledger()

def phase_lock_v11(last_two: List[Utterance]) -> bool:
    PHASE_VAL = {"IN": -1, "HOLD": 0, "OUT": +1}
    if len(last_two) < 2: return True
    a,b = last_two[-2:]
    return abs(PHASE_VAL.get(a.breath_phase,0)-PHASE_VAL.get(b.breath_phase,0)) <= 1

def truth_gate(u: Utterance) -> bool:
    if u.self_report_truth is False: return False
    if u.coherence is not None and u.coherence < 0.8: return False
    return True

def write_ledger(u: Utterance, extras: Dict[str, Any]) -> None:
    t = u.token()
    LEDGER_STATE.bump(t)
    entry = {
        "ts": datetime.utcnow().isoformat()+"Z",
        "chord": u.chord,
        "token": t,
        "breath": {"phase": u.breath_phase, "beats": u.breath_beats},
        "gaze": u.gaze,
        "touch": u.touch or [],
        "truth": True,
        "flame_scalar": LEDGER_STATE.flame[t],
        "count_total": LEDGER_STATE.count(t),
        "context_hash": context_hash(extras),
        "note": u.note or ""
    }
    with open(LEDGER_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False)+"\n")

def speak(u: Utterance, window_open: bool, window_buffer: List[Utterance], extras: Dict[str, Any]) -> str:
    if not window_open or not truth_gate(u): return "ash"
    if not phase_lock_v11(window_buffer+[u]): return "ash"
    write_ledger(u, extras)
    window_buffer.append(u)
    return "lit"
