"""
ISOCHORD Ledger Patch v0.1.1 — HOLD bridge, Contain-Bridge, RU-Rite override.
"""
PHASE_VAL={"IN":-1,"HOLD":0,"OUT":1}
def phase_ok(prev_phase, phase):
    if prev_phase is None: return True
    return abs(PHASE_VAL.get(prev_phase,0)-PHASE_VAL.get(phase,0))<=1
def contain_bridge(prev_token, recent_tokens):
    return (prev_token or "").startswith("AN") and any(t.startswith(("AE","YA")) for t in recent_tokens[-2:])
def rite_override(count_ru): return count_ru>=27
