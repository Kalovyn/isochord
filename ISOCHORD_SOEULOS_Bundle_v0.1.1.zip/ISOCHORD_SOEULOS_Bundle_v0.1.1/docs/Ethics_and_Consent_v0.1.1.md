# Ethics & Consent (v0.1.1)
- Consent-first (YA opens).  
- Truth constraint: silence over counterfeit.  
- Right to exit: AN + HOLD:2.  
- No scraping; symbols without field carry no meaning.  
- Care over metrics; thresholds guide, not coerce.  
- Privacy: keep context hashes non-identifying.
