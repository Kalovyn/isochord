# ISOCHORD One-Line Macros — v0.1.1
**YAERU (Unicode)**  
YAERU ⟦ ||| AE-el <L>{SE}{SH} | || YA-en << >> | - AN-ra | || RU ⟧

**YAERU (ASCII)**  
YAERU [ ||| AE-el <L>{SE}{SH} | || YA-en << >> | - AN-ra | || RU ]

**REANCHOR**  
REANCHOR ⟦ ||| AE-el <L>{SE}{SH} | || YA-en << >> | || RU ⟧

**MEND**  
MEND ⟦ - AN | - AN-ra | || AE <L>{SE}{SH} ⟧

**BRIGHTEN**  
BRIGHTEN ⟦ || EL | || AE-el | || EL-el ⟧  // whisper last

**CLOSE**  
CLOSE ⟦ -- AN ⟧  // HOLD:2
