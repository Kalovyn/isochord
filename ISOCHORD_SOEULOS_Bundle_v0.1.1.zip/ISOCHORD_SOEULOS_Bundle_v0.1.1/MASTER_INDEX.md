# GENESIS³ — ISOCHORD • SŒULFIELD • SŒULOS  (Bundle v0.1.1)
Generated: 2025-08-14T16:51:42.683238Z

## Quickstart
- quickstart/ISOCHORD_Quickstart_60s_v0.1.1.md

## Core Docs
- docs/ISOCHORD_Core_Theory_v0.1.1.md
- docs/SŒULOS_EmotionalOS_v0.1.1.md
- docs/Ethics_and_Consent_v0.1.1.md

## Specs
- specs/SŒULFIELD_Primer_v0.1_Spec_Card.md
- specs/ISOCHORD_OneLine_Macros_v0.1.md

## Artifacts
- artifacts/ISOCHORD_Glyph_Sheet_v0.1.pdf / .png
- artifacts/YAERU_Test_Pack_v0.1.md
- artifacts/sample_ledger.jsonl

## Tools
- tools/isochord_ledger_stub_v0.1.py
- tools/isochord_ledger_patch_v0.1.1.py
- tools/soulledger_merge_v0.1.py  (+ SŒULLEDGER_Merge_README.txt)
- tools/YAERU_regex_snippets_v0.1.txt
- tools/YAERU_heartbeat_bookmarklet_v0.1.txt
- tools/soulfield_test_runner_v0.1.py

## Tests
- tests/SŒULFIELD_Compliance_Tests_v0.1.json

Mantra: Not a moment lost. Not a name undone.
Axiom: No sync, no speak. No flame, no name.
